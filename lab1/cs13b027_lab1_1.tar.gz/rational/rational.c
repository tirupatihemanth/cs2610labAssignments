/*
 * Author: <Your Name>
 * Rational data structure (Implementation)
 */

#include "rational.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Additional functions
rational rational_lowestform(rational);
int gcd ( int,int);
int gcd(int a, int b){
  int temp;
  if(a<b){
   temp=a;
   a=b;
   b=temp;
  }
  while(b!=0){
    temp=b;
    b=a%b;
    a=temp;
  }
  return a;
} 
rational rational_lowestform(rational ratnl){
  //printf("%d 1\n",ratnl.num);
  //printf("%d 2\n",ratnl.den);
  if(ratnl.num!=0 && ratnl.den!=0){
  int gcdval = gcd(ratnl.num,ratnl.den);
  ratnl.num/=gcdval;
  ratnl.den/=gcdval;
  }
  return ratnl;
}

rational make_rational(int p,int q){
  rational ratnl;
  ratnl.num=p;
  ratnl.den=q;
  return ratnl;
}
rational rational_parse(char* str){
  int a,i,j;
  for(i=0;i<strlen(str);i++){
    if(str[i]=='/')
      break;
  }
  //printf("%d i\n",i);
  char arr[i];
  char *p;
  p=&str[i+1];
  for(j=0;j<i;j++)
    arr[j]=str[j];
  arr[i]='\0';
  //printf("%s %d 1\n",arr,strlen(arr));
  //printf("%s %d 2\n",p,strlen(p));
  //printf("%d 3\n",atoi(arr));
  //printf("%d 4\n",atoi(p));
  return make_rational(atoi(arr),atoi(p));
}
void rational_print(rational ratnl){
  ratnl=rational_lowestform(ratnl);
  printf("%d/%d\n",ratnl.num,ratnl.den);
}
rational rational_from_int(int p){
  return make_rational(p,1);
}
double rational_to_double(rational ratnl){
  return ((ratnl.num*1.0)/ratnl.den);
}

rational rational_add(rational ratnl1,rational ratnl2){
  return make_rational(ratnl1.num*ratnl2.den+ratnl2.num*ratnl1.den,ratnl1.den*ratnl2.den);
}
rational rational_sub(rational ratnl1,rational ratnl2){
  return make_rational(ratnl1.num*ratnl2.den-ratnl2.num*ratnl1.den,ratnl1.den*ratnl2.den);
}
rational rational_mul(rational ratnl1,rational ratnl2){
  return make_rational(ratnl1.num*ratnl2.num,ratnl1.den*ratnl2.den);
}
rational rational_div(rational ratnl1,rational ratnl2){
  return make_rational(ratnl1.num*ratnl2.den,ratnl1.den*ratnl2.num);
}
rational rational_reciprocate(rational ratnl){
  return make_rational(ratnl.den,ratnl.num);
}