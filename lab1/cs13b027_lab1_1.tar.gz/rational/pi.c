/*
 * Author: Tirupati Hemanth Kumar
 * Compute pi using continued fractions
 */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "rational.h"
int main( int argc, char* argv[] )
{
  int i;
  int arr[22]={3,7,15,1,292,1,1,1,2,1,3,1,14,2,1,1,2,2,2,2,1,84};
  int n;
  scanf("%d",&n);
    if(n ==0){
    printf("INVALID");
    exit(1);
    } 
    rational ans=rational_from_int(arr[n-1]);
  for(i=n-2;i>=0;i--){
      //rational_print(rational_from_int(arr[i]));
      //rational_print(rational_reciprocate(ans));
      ans=rational_add(rational_from_int(arr[i]),rational_reciprocate(ans));
      //rational_print(ans);
    }
    //rational_print(ans);
    double val = rational_to_double(ans);
    //printf("%f",rational_to_double(ans));
    printf("%e\n",(M_PI-val)/M_PI);
    return 0;
}
