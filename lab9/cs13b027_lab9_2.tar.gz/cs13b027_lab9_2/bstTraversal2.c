/*
 * Name: Tirupati Hemanth Kumar
 * Roll No.: cs13b027
 * Given pre order traversal of a bstree obtain the post order traversal of the bstree without constructing the binary search tree
 */



#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void print_postorder(int, int);

int *inorder,n;

int main(){

	int i;
	scanf("%d",&n);
	inorder = (int *) malloc(sizeof(int)*n);
	for(i=0;i<n;i++){
		scanf("%d",inorder+i);
	}
	print_postorder(INT_MIN,INT_MAX);
	return 0;
}


void print_postorder(int min, int max){
	int i;
	for(i=0;i<n;i++){
		if(inorder[i]>min && inorder[i]<max){
			break;
		}
		else if(i == n-1)
			return;
	}
	print_postorder(min,inorder[i]);
	print_postorder(inorder[i],max);
	printf("%d ",inorder[i]);
}