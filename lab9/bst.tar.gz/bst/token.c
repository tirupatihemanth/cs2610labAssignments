/*
 * Author: <Your Name>
 * Token System
 */
#include "BSTree.h"

int main( int argc, char* argv[] )
{
  // TODO: Read a stream of integers using scanf. Stop when you see a
  //       -1
  // TODO: For each token - check if the token exists in the
  //       collection. If no - add to the collection. If yes - remove.
  // TODO: Print when done

  return 0;
}

