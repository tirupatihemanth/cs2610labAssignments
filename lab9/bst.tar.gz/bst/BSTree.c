/*
 * Author: <Your Name>
 * Binary Search Tree data structure (Implementation)
 */

#include "BSTree.h"

