#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
void main(){
  
    //Variable Declarations
  
    int i,j,k,mat1_r,mat1_c,mat2_r,mat2_c,counter;
    int **mat1,**mat2,**mat3;
    srand(time(NULL));
    scanf("%d %d %d %d %d",&mat1_r,&mat1_c,&mat2_r,&mat2_c,&k);
    printf("%d k\n",k);
    
    //Declaring pointers for frequency matrices and allocating memory to them
    
   /* 
    int *freq_mat1,*freq_mat2;
    freq_mat1 = (int *) malloc(sizeof(int)*(k+1));
    freq_mat2 = (int *) malloc(sizeof(int)*(k+1));
   */
    //Verifying whether matrices can be multiplied or not
    
    if(mat1_c!=mat2_r){
	printf("ERROR");
	exit(1);
    }
    
    //Allocating memories with malloc and forming a 2d array of integers
    
    mat1 = (int**)malloc(sizeof(int*)*mat1_r);
    mat2 = (int**)malloc(sizeof(int*)*mat2_r);
    mat3 = (int**)malloc(sizeof(int*)*mat1_r);
    for(i=0;i<mat1_r;i++){
	mat1[i] = (int *)malloc(sizeof(int)*mat1_c);
	mat3[i] = (int *)malloc(sizeof(int)*mat2_c);
    }
    for(i=0;i<mat2_r;i++)
	mat2[i] = (int *)malloc(sizeof(int)*mat2_c);
    
    
    
    //Initialising the frequency matrices to zeroes
    
  /*  for(i=0;i<(k+1);i++){
      freq_mat1[i]=0;
      freq_mat2[i]=0;
    }*/
    
  /*  for(i=0;i<(k+1);i++){
      printf("%d ",freq_mat1[i]);
    }
    */
    //Setting up the frequencies in the first frequency matrix from first input matrix
    
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat1_c;j++){
	    mat1[i][j]= rand()%(k)+1;
	    //freq_mat1[mat1[i][j]]++;
	}
    }
    
    //Setting up the frequencies in the second frequeny matrix from the second input matrix
    
    for(i=0;i<mat2_r;i++){
	for(j=0;j<mat2_c;j++){
	    mat2[i][j] = rand()%(k)+1;
	    //freq_mat2[mat1[i][j]]++;
	}
    }
    
    //Initialising the final matrix to zeroes
    
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat2_c;j++){
	    mat3[i][j] = 0;
	}
    }
    
    //printing the first input matrix
   
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat1_c;j++){
	    printf("%d ",mat1[i][j]);
	}
	printf("\n");
    }
    
    //printing the second input matrix
    
    for(i=0;i<mat2_r;i++){
	for(j=0;j<mat2_c;j++){
	    printf("%d ",mat2[i][j]);
	}
	printf("\n");
    }
    
    //Doing the Multiplication operation of two matrices
    
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat2_c;j++){
	    for(counter=0;counter<mat1_c;counter++){
		mat3[i][j]+=(mat1[i][counter]*mat2[counter][j]);
	    }
	}
    }
    //printing the final multiplied matrices
    
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat2_c;j++)
	    printf("%d ",mat3[i][j]);
	printf("\n");
    }
    
    //Optional code written to verify the sufficient randomness of the numbers in the matrices
    
   /*printf("Frequencies\n");
    for(i=1;i<k+1;i++){
      //printf("%d ",freq_mat1[i]);
    }
    printf("\n");
    for(i=1;i<k+1;i++){
      //printf("%d ",freq_mat2[i]);
    }
    */
   
    //freeing all the memory allocated through malloc using free()
    
    for(i=0;i<mat1_r;i++){
	free(mat1[i]);
	free(mat3[i]);
    }
    for(i=0;i<mat2_r;i++)
	free(mat2[i]);
    free(mat1);
    free(mat2);
    free(mat3);
    
}