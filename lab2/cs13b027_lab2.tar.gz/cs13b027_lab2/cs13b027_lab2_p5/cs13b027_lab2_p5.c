#include <stdio.h>
#include "BigInt.h"
#include <string.h>
#include <stdlib.h>

bigint randbigint(bigint);
void main(){
        srand(time(NULL));
    //Variable Declarations
    
    int i,j,mat1_r,mat1_c,mat2_r,mat2_c,counter;
    char str[512];
    bigint **mat1,**mat2,**mat3;
    scanf("%d %d %d %d %s",&mat1_r,&mat1_c,&mat2_r,&mat2_c,str);
    bigint k;
    k= make_bigint(str);
    if(mat1_c!=mat2_r){
	printf("ERROR");
	exit(1);
    }
    
    mat1 = (bigint**)malloc(sizeof(int*)*mat1_r);
    mat2 = (bigint**)malloc(sizeof(int*)*mat2_r);
    mat3 = (bigint**)malloc(sizeof(int*)*mat1_r);
    
    for(i=0;i<mat1_r;i++){
	mat1[i] = (bigint *)malloc(sizeof(bigint)*mat1_c);
	mat3[i] = (bigint *)malloc(sizeof(bigint)*mat2_c);
    }
    for(i=0;i<mat2_r;i++)
	mat2[i] = (bigint *)malloc(sizeof(bigint)*mat2_c);
    
    //filling of matrices with random values in mat1
    
     for(i=0;i<mat1_r;i++){
	for(j=0;j<mat1_c;j++){
	    mat1[i][j]= randbigint(k);
	}
    }
    
    //Filling of Second Matrix with random values in mat2
    
    for(i=0;i<mat2_r;i++){
	for(j=0;j<mat2_c;j++){
	    mat2[i][j]= randbigint(k);
	}
    }
    
    //Filling of Third Matrix which is the resultant matrix computed using matrix multiplication rules
    
      for(i=0;i<mat1_r;i++){
	for(j=0;j<mat2_c;j++){
	    for(counter=0;counter<mat1_c;counter++){
		mat3[i][j] = bigint_add(mat3[i][j],bigint_mul(mat1[i][counter],mat2[counter][j]));
	    }
	}
    }
    
    //Printing the First Input Matrix
    
   for(i=0;i<mat1_r;i++){
	for(j=0;j<mat1_c;j++){
	  print_bigint(mat1[i][j]);
	  printf(" ");
	}
	printf("\n");
    }
    
    printf("\n");
    
    //printing the second input matrix
    
    for(i=0;i<mat2_r;i++){
	for(j=0;j<mat2_c;j++){
	    print_bigint(mat2[i][j]);
	    printf(" ");
	}
	printf("\n");
    }
    
    printf("\n");
    
    //Printing the resultant matrix obtained after multiplication
    
    for(i=0;i<mat1_r;i++){
	for(j=0;j<mat2_c;j++){
	    print_bigint(mat3[i][j]);
	    printf(" ");
	}
	printf("\n");
    }
    
    
}

//This function is to generate random big integers

bigint randbigint(bigint k){
  
    // Function to give random bigintegers where algorithm used to generate each single digit without bias and hence getting the resultant bigint an unbiased number
  
    int i,stat=1;
    int len = k.length;
    char randstr[len];
    while(stat==1){
    for(i=0;i<len;i++){
      if(i == 0){
	int temp = k.value[0]-'0';
	randstr[0] = (char)(rand()%(temp+1)+48);
      }
      else{
	randstr[i]=(char)((rand()%10)+48);
      }
      
    }
    randstr[len]='\0';
      if(strcmp(randstr,k.value)<=0){
      stat=0;
      return make_bigint(randstr);
      }
      else
	stat=1;
    }
 }

