#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void main(){
  
  //Varible declarations
  
  int a,b,i;
  scanf("%d %d",&a,&b);
  char *ptr1,*ptr2;
  
  //Allocating memory dynamically using malloc
  
  ptr1=(char *)malloc(sizeof(char)*a);
  ptr2=(char *)malloc(sizeof(char)*a);
  scanf("%s %s",ptr1,ptr2);
  
  //Printing the resulting sequence of characters
  
  for(i=0;i<a+b;i++){
    if(i<a)
      printf("%c",ptr1[i]);
    if(i<b)
      printf("%c",ptr2[i]);
  }
  
  //Freeing all the memory that was allocated using malloc
  
  free(ptr1);
  free(ptr2);
}