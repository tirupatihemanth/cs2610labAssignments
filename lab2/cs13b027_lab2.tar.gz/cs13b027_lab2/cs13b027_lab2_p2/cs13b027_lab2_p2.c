#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int rows,cols;
char**pre_state;
int value(int,int);
void main(){
  
    //Variable Declarations
  
    int i,j,k;
    char**cur_state;
    scanf("%d %d %d",&rows,&cols,&k);
    
    //Allocating memories using malloc and thus forming 2d arrays
    
    cur_state =(char**) malloc(sizeof(char*)*rows);
    pre_state =(char**) malloc(sizeof(char*)*rows);
    for(i=0;i<rows;i++){
	cur_state[i] = (char *)malloc(sizeof(char)*cols);
	pre_state[i] = (char *)malloc(sizeof(char)*cols);
    }
    
    //Taking the initial state of the system as input from the user
    
    for(i=0;i<rows;i++){
	for(j=0;j<cols;j++){
	    scanf("%d",&pre_state[i][j]);
	    cur_state[i][j]=pre_state[i][j];
	}
    }/*
     for(i=0;i<rows;i++){
	for(j=0;j<cols;j++){
	    printf("%d ",cur_state[i][j]);
	}
	printf("\n");
    }*/
    
    //Looping for the number of times as specified
    
    while(k>0){
	for(i=0;i<rows;i++){
	    for(j=0;j<cols;j++){
		if(value(i,j)<2)
		    cur_state[i][j]=0;
		if(value(i,j)>3)
		    cur_state[i][j]=0;
		if(value(i,j)==3)
		    cur_state[i][j]=1;
	    }
	}
	for(i=0;i<rows;i++){
	    for(j=0;j<cols;j++){
		pre_state[i][j]=cur_state[i][j];
	    }
	}
	k--;
    }
    
    //Printin the current state of the system after k Iterations
    
    for(i=0;i<rows;i++){
	for(j=0;j<cols;j++){
	    printf("%d ",cur_state[i][j]);
	}
	printf("\n");
    }
    
    //Freeing all the memory that was allocated using malloc
    
    for(i=0;i<rows;i++){
	free(cur_state[i]);
	free(pre_state[i]);
    }
    free(cur_state);
    free(pre_state);
}

int value(int i, int j){
    
    //This is function to return the sum of all the surrounding element statuses
  
    int value=0;
    if(i>0){
	value+=pre_state[i-1][j];
	if(j>0)
	    value+=pre_state[i-1][j-1];
    }
    if(i<rows-1){
	value+=pre_state[i+1][j];
	if(j<cols-1)
	    value+=pre_state[i+1][j+1];
    }
    if(j>0){
	value+=pre_state[i][j-1];
	if(i<rows-1)
	    value+=pre_state[i+1][j-1];
    }
    if(j<cols-1){
	value+=pre_state[i][j+1];
	if(i>0)
	    value+=pre_state[i-1][j+1];
    }
    return value;	
}
