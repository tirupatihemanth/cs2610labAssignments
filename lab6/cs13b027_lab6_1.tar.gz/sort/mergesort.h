/*
 * Author: Tirupati Hemanth Kumar
 * Roll No.: cs13b027
 * Header file for mergesort.c 
 *
 */

#ifndef MERGESORT_H
#define MERGESORT_H

void mergesort(int * ,int, int);
void merge(int* ,int ,int ,int ,int);

#endif