//program to check if a string is permutation of another string
/*The algorithm used is to consider an integer array of 58 length which is initialised to zero and when you find an element corresponding array integer is incremented by one and corresponding element is decreased if an element is found in another string so finally status of all the elements in the array will be zero if the strings are permutations*/
#include<stdio.h>
#include<string.h>
void main(){
  int i;
  int status[58]={0};
  char str1[100];
  char str2[100];
  scanf("%s%s",str1,str2);
  if(strlen(str1)==strlen(str2)){
    for(i=0;i<strlen(str1);i++){
    status[str1[i]-'A']+=1;
    status[str2[i]-'A']-=1;
  }
  for(i=0;i<58;i++){
    if(status[i]!=0){
      printf("%d",0);
      return;
    }
  }
    printf("%d\n",1);
  }
  else 
    printf("%d\n",0);
  
}
