//Program to determine no. of characters to be appended to a string to make it a palindrome
/*Iterating from the first character of the element check if the rest of the string is palindrome if it is a palindrome then no. of characters you moved will be the number of characters you have to append to make it a palindrome*/
#include<stdio.h>
#include<string.h>
int isPalindrome(char *);
void main(){
  int i,j,k;
  char str[100];
  char *p;
  scanf("%s",str);
  for(i=0;i<strlen(str);i++){
    p=&str[i];
    if(isPalindrome(p))
      break;
  }
  printf("%d\n",i);
}

int isPalindrome(char *str){
  //This function returns 1 if the input is a Palindrome else returns 0;
  int i=0;
  for(i=0;i<strlen(str)/2;i++){
    if(str[i]!=str[strlen(str)-1-i])
      return 0;
  }
  return 1;
}
