//program to obtain the reverse of a string
//A recursive algorithm has been implemented
#include<stdio.h>
#include<string.h>
void strrev(char *);
void main(){
  char str[100];
  scanf("%s",str);
  strrev(str);
}
void strrev(char *str){
  //This function is used to recursively print the reverse of a string
  if(strlen(str)==0){
    printf("\n");
    return;
  }
  printf("%c",str[strlen(str)-1]);
  str[strlen(str)-1]='\0';
  strrev(str);
}
