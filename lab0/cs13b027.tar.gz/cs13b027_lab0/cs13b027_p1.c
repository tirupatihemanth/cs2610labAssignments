//program to get the GCD of two given numbers using division algorithm
//Also using that gcd of two numbers irrespective of their variation in their sign is always same
#include<stdio.h>
void main(){
  int m,n,temp;
  scanf("%d %d",&m,&n);
// To make sure that always m>n we swap them if m<n
  if(m<n){
    temp=m;
    m=n;
    n=temp;
  }
  while(n!=0){
    temp=n;
    n=m%n;
    m=temp;
  }
  printf("%d\n",m);
  if(m<0)
    printf("%d\n",-m);
}
