//program is to check if a string is rotation of another
//Algorithm is if the rotated string is joined to the end of itself then the original string is a subset of this string
#include<stdio.h>
#include<string.h>
void main(){
  char str1[100],str2[100],str3[200];;
  scanf("%s %s",str1,str2);
  //printf("%s %s",str1,str2);
  strcpy(str3,str2);
  strcat(str3,str2);
  if(strstr(str3,str1)!=NULL){
    printf("%d\n",1);
  }
  else printf("%d\n",0);
}
