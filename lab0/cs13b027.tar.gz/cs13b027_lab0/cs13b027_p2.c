//program to check if the string given has all characters distinct
//uses a 26 character string to know the status of each element in the string
#include<stdio.h>
#include<string.h>
void main(){
  int i;
  char str[100];
  scanf("%s",str);
  char status[26]="00000000000000000000000000";
  for(i=0;i<strlen(str);i++){
    if(status[str[i]-'a']=='0'){
      status[str[i]-'a']='1';
    }
    else{
      printf("%d\n",0);
      return;
    }
  }
   printf("%d\n",1);
}
